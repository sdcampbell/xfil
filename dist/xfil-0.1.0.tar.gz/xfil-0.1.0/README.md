# xfil
xfil is a tool that performs blind XPath exploitation and data exfiltration. This tool is created for penetration testers performing authorized security assessments.
